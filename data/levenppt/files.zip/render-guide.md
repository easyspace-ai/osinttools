# PptxGenJS 渲染指南

将 Slide Schema JSON 转换为 Node.js 脚本并运行，输出 .pptx 文件。

---

## 环境准备

```bash
npm install pptxgenjs react react-dom react-icons sharp --save
```

> sharp 用于将 react-icons SVG 转为 PNG；react-icons 提供 2000+ 图标。

---

## 脚本基础结构

```javascript
const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");

// 你的 Slide Schema
const schema = require("./schema.json");

async function buildPresentation() {
  const pres = new pptxgen();
  pres.layout = schema.meta.layout || "LAYOUT_16x9";
  pres.title = schema.meta.title;
  pres.author = schema.meta.author || "AI Generated";

  for (const slideData of schema.slides) {
    const slide = pres.addSlide();
    slide.background = { color: slideData.bg_color || "FFFFFF" };
    await renderSlide(pres, slide, slideData, schema.meta.theme);
  }

  await pres.writeFile({ fileName: "output.pptx" });
  console.log("✅ output.pptx 生成成功");
}

buildPresentation().catch(console.error);
```

---

## 元素渲染函数

### 文字（text / bullets）

```javascript
async function renderElement(pres, slide, el, theme) {
  switch (el.kind) {

    case "text":
      slide.addText(el.text, {
        x: el.x, y: el.y, w: el.w, h: el.h,
        fontSize: el.fontSize || 18,
        fontFace: el.fontFace || theme.font_body || "Calibri",
        color: el.color || theme.text_dark,
        bold: el.bold || false,
        italic: el.italic || false,
        align: el.align || "left",
        valign: el.valign || "top",
        margin: el.margin !== undefined ? el.margin : 4,
        lineSpacingMultiple: el.lineSpacingMultiple,
        wrap: true,
      });
      break;

    case "bullets":
      const bulletItems = el.items.map((item, i) => ({
        text: item,
        options: {
          bullet: true,
          fontSize: el.fontSize || 16,
          color: el.color || theme.text_dark,
          breakLine: i < el.items.length - 1,
          paraSpaceAfter: 8,
        }
      }));
      slide.addText(bulletItems, {
        x: el.x, y: el.y, w: el.w, h: el.h,
        fontFace: el.fontFace || theme.font_body || "Calibri",
      });
      break;
```

### 形状（shape）

```javascript
    case "shape":
      slide.addShape(pres.shapes[el.shape] || pres.shapes.RECTANGLE, {
        x: el.x, y: el.y, w: el.w, h: el.h,
        fill: { color: el.fill || "CCCCCC" },
        line: el.stroke ? { color: el.stroke, width: el.strokeWidth || 1 } : { color: el.fill || "CCCCCC", width: 0 },
        rectRadius: el.rectRadius,
        shadow: el.shadow ? makeShadow(el.shadow) : undefined,
      });
      break;
```

### 图表（chart）

```javascript
    case "chart":
      const chartData = el.data.map(series => ({
        name: series.name,
        labels: series.labels || el.data.map(s => s.name),
        values: series.values,
      }));

      slide.addChart(pres.charts[el.chartType] || pres.charts.BAR, chartData, {
        x: el.x, y: el.y, w: el.w, h: el.h,
        barDir: el.barDir || "col",
        chartColors: (el.chartColors || [theme.primary, theme.secondary, theme.accent]),
        chartArea: { fill: { color: "FFFFFF" }, roundedCorners: true },
        catAxisLabelColor: "64748B",
        valAxisLabelColor: "64748B",
        valGridLine: { color: "E2E8F0", size: 0.5 },
        catGridLine: { style: "none" },
        showValue: el.showValue !== false,
        dataLabelColor: "1E293B",
        showLegend: el.showLegend || false,
        legendPos: el.legendPos || "b",
        lineSize: el.lineSize,
        lineSmooth: el.lineSmooth,
        showPercent: el.showPercent,
      });
      break;
```

### 图标（icon / icon_group）

```javascript
    case "icon":
    case "icon_group":
      await renderIcons(slide, el);
      break;
```

```javascript
// 图标渲染辅助函数
async function iconToBase64Png(iconName, color = "#000000", size = 256) {
  // 从 react-icons 动态加载
  const iconSets = [
    require("react-icons/fa"),
    require("react-icons/md"),
    require("react-icons/hi"),
    require("react-icons/bi"),
  ];
  let IconComponent;
  for (const set of iconSets) {
    if (set[iconName]) { IconComponent = set[iconName]; break; }
  }
  if (!IconComponent) {
    console.warn(`⚠️ 图标未找到: ${iconName}，跳过`);
    return null;
  }
  const svg = ReactDOMServer.renderToStaticMarkup(
    React.createElement(IconComponent, { color, size: String(size) })
  );
  const pngBuffer = await sharp(Buffer.from(svg)).png().toBuffer();
  return "image/png;base64," + pngBuffer.toString("base64");
}

async function renderIcons(slide, el) {
  if (el.kind === "icon") {
    const data = await iconToBase64Png(el.name, "#" + el.color, 256);
    if (data) slide.addImage({ data, x: el.x, y: el.y, w: el.w, h: el.h });
    return;
  }

  // icon_group：垂直排列图标组
  const icons = el.icons;
  const itemH = el.h / icons.length;
  for (let i = 0; i < icons.length; i++) {
    const ic = icons[i];
    const iy = el.y + i * itemH;
    const data = await iconToBase64Png(ic.name, "#" + ic.color, 256);
    if (data) slide.addImage({ data, x: el.x, y: iy + 0.05, w: 0.45, h: 0.45 });
    slide.addText(ic.label, {
      x: el.x + 0.55, y: iy, w: el.w - 0.55, h: itemH,
      fontSize: 15, color: ic.color, bold: true, valign: "middle",
    });
  }
}
```

### 卡片网格（card_grid）

```javascript
async function renderCardGrid(pres, slide, el, theme) {
  const { cards, columns = 2, x, y, w, h, card_fill, title_color, body_color } = el;
  const rows = Math.ceil(cards.length / columns);
  const cardW = (w - (columns - 1) * 0.2) / columns;
  const cardH = (h - (rows - 1) * 0.15) / rows;

  for (let i = 0; i < cards.length; i++) {
    const card = cards[i];
    const col = i % columns;
    const row = Math.floor(i / columns);
    const cx = x + col * (cardW + 0.2);
    const cy = y + row * (cardH + 0.15);

    // 卡片背景
    slide.addShape(pres.shapes.ROUNDED_RECTANGLE, {
      x: cx, y: cy, w: cardW, h: cardH,
      fill: { color: card_fill || "FFFFFF" },
      line: { color: "E2E8F0", width: 0.5 },
      rectRadius: 0.08,
      shadow: { type: "outer", blur: 6, offset: 2, angle: 135, color: "000000", opacity: 0.08 },
    });

    // 图标
    if (card.icon) {
      const data = await iconToBase64Png(card.icon, "#" + (card.icon_color || theme.primary), 256);
      if (data) slide.addImage({ data, x: cx + 0.2, y: cy + 0.2, w: 0.4, h: 0.4 });
    }

    // 标题
    slide.addText(card.title, {
      x: cx + 0.15, y: cy + 0.65, w: cardW - 0.3, h: 0.45,
      fontSize: 15, bold: true, color: title_color || theme.primary, fontFace: "Calibri",
    });

    // 正文
    slide.addText(card.body, {
      x: cx + 0.15, y: cy + 1.1, w: cardW - 0.3, h: cardH - 1.25,
      fontSize: 12, color: body_color || "555555", fontFace: "Calibri",
      wrap: true, lineSpacingMultiple: 1.3,
    });
  }
}
```

### 数据看板（stat_group）

```javascript
async function renderStatGroup(slide, el, theme) {
  const { stats, x, y, w, h } = el;
  const itemH = h / stats.length;
  for (let i = 0; i < stats.length; i++) {
    const stat = stats[i];
    const sy = y + i * itemH;

    // 大数字
    slide.addText(stat.value, {
      x, y: sy, w, h: itemH * 0.6,
      fontSize: 36, bold: true, color: stat.color || theme.primary,
      align: "center", valign: "bottom",
    });
    // 标签
    slide.addText(stat.label, {
      x, y: sy + itemH * 0.6, w, h: itemH * 0.35,
      fontSize: 13, color: "888888", align: "center",
    });
  }
}
```

---

## 常见陷阱（每次写代码前复查）

1. **颜色不加 `#`** — `color: "FF0000"` ✅，`color: "#FF0000"` ❌（破坏文件）
2. **shadow 不用 8 位 hex 透明度** — 用 `opacity: 0.15` 属性，不要 `"00000026"` ❌
3. **不重用 options 对象** — 每次调用用新对象或工厂函数，PptxGenJS 会 mutate
4. **bullets 用 `bullet: true`** — 不要用 `"•"` Unicode 前缀，会双重显示
5. **多行文字用 `breakLine: true`** — 不要靠换行符
6. **ROUNDED_RECTANGLE 不配矩形边框** — 圆角会露出，改用 `RECTANGLE`

---

## 调试工具

```bash
# 提取文字内容
extract-text output.pptx

# 检查占位符遗留
extract-text output.pptx | grep -iE "TODO|lorem|XXXXX|\[insert"

# 转图片检查视觉
python scripts/office/soffice.py --headless --convert-to pdf output.pptx
pdftoppm -jpeg -r 150 output.pdf slide
```
