# 质检指南

生成 .pptx 后必须执行此流程，确保输出专业可用。

---

## 第 1 步：内容校验

```bash
extract-text output.pptx
```

检查项：
- [ ] 所有幻灯片标题存在且不重复
- [ ] 要点文字完整，无截断
- [ ] 无占位符遗留（见下方命令）
- [ ] 中英文语言一致（如有要求）

```bash
# 扫描常见占位符
extract-text output.pptx | grep -iE "\bXXX\b|lorem|ipsum|TODO|\[insert|placeholder|示例文字"
```

如有结果 → 立即修改 schema 或脚本中的对应内容，重新生成。

---

## 第 2 步：视觉截图检查

```bash
# 生成截图
python scripts/office/soffice.py --headless --convert-to pdf output.pptx
rm -f slide-*.jpg
pdftoppm -jpeg -r 150 output.pdf slide
ls -1 "$PWD"/slide-*.jpg
```

用 `view` 工具加载每张截图，检查以下问题：

| 问题 | 严重度 | 处理 |
|------|--------|------|
| 文字溢出边框 | 高 | 必须修复 |
| 元素重叠（非预期） | 高 | 必须修复 |
| 文字被裁剪 | 高 | 必须修复 |
| 标题与正文间距过小 | 中 | 建议修复 |
| 图标颜色对比度低 | 中 | 建议修复 |
| 字体大小不统一 | 低 | 选择性修复 |
| 子像素对齐偏差 | 忽略 | 不修复 |

---

## 第 3 步：修复循环

发现高/中严重度问题时：

1. 定位到 schema JSON 中对应幻灯片和元素
2. 调整坐标、尺寸或文字内容
3. 重新运行 `node generate.js`
4. 重新截图（必须重新运行全部 4 条命令，PDF 需重新生成）
5. 再次检查被修复的幻灯片

**停止条件**：一轮修复后若无新的用户可见缺陷，停止迭代。不要追求像素级完美。

---

## 第 4 步：交付

```bash
cp output.pptx /mnt/user-data/outputs/presentation.pptx
```

然后调用 `present_files` 工具将文件交付给用户。

---

## 常见视觉问题与解决方案

### 文字溢出文字框

**原因**：`h` 设置太小，或字体过大。

```json
// 修复前
{ "kind": "text", "text": "...", "h": 0.4, "fontSize": 18 }

// 修复后：增大 h，或减小 fontSize
{ "kind": "text", "text": "...", "h": 0.8, "fontSize": 16 }
```

### 元素互相遮挡

**原因**：x/y 坐标计算错误，两个元素占用同一区域。

检查方法：对每两个元素，验证 `el1.x + el1.w <= el2.x`（水平）或 `el1.y + el1.h <= el2.y`（垂直）。

### 标题页背景色未铺满

**原因**：shape 元素的尺寸小于幻灯片（16x9 = 10" × 5.625"）。

```json
// 全屏背景形状
{ "kind": "shape", "shape": "RECTANGLE", "x": 0, "y": 0, "w": 10, "h": 5.625, "fill": "1A1A2E" }
```

### 图标显示为空白

**原因**：react-icons 图标名称错误，或 sharp 未安装。

```bash
# 验证图标名称
node -e "const fa = require('react-icons/fa'); console.log(typeof fa.FaCheckCircle)"
# 应输出 "function"，否则换图标名
```

### 配色 # 号破坏文件

**原因**：PptxGenJS 颜色字段不加 `#`，加了会静默生成损坏文件。

全局搜索替换：`grep -n '"#' generate.js` → 逐条去掉 `#`。
