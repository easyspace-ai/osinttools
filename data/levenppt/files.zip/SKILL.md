---
name: ai-pptx-gen
description: >
  使用 AI + PptxGenJS 自动生成高质量 PowerPoint 演示文稿。
  当用户提到"生成PPT"、"制作幻灯片"、"做一个演示"、"pptxgenjs"、"自动生成演示文稿"，
  或者提供主题/文字/文件要求输出 .pptx 时，必须使用此 skill。
  同样适用于：批量生成多份PPT、根据数据动态建幻灯片、AI辅助PPT产品开发。
---

# AI + PptxGenJS 生成 PPT

## 概览

本 skill 将 Claude 的内容规划能力与 PptxGenJS 的精准渲染结合，分四个阶段输出专业 .pptx 文件。

| 阶段 | 工作 | 参考文件 |
|------|------|---------|
| 1. 意图理解 | 明确主题、风格、页数、受众 | 本文件 |
| 2. AI 内容规划 | 大纲 → Slide Schema JSON | [slide-schema.md](references/slide-schema.md) |
| 3. PptxGenJS 渲染 | JSON → Node.js 脚本 → .pptx | [render-guide.md](references/render-guide.md) |
| 4. 质检与修复 | 截图 → 视觉/内容校验 → 修复 | [qa-guide.md](references/qa-guide.md) |

---

## 阶段 1：意图理解

收集以下信息（未提供时使用括号内的默认值）：

- **主题** — 必填
- **受众** — 技术/商业/学术/通用（默认：通用）
- **页数** — 5-20（默认：8）
- **风格** — 商务/科技/创意/简约（默认：商务）
- **配色** — 见 [render-guide.md](references/render-guide.md) 色彩系统
- **语言** — 中文/英文（默认：中文）
- **数据文件** — 用户上传的 PDF/DOCX/CSV（有则提取内容）

信息充足后，**无需再次确认，直接进入阶段 2**。

---

## 阶段 2：AI 内容规划

### 2.1 生成大纲

按以下结构思考每张幻灯片，然后输出 Slide Schema JSON：

```
标题页 → 目录/概述 → 核心内容页(N张) → 数据/图表页 → 结论/CTA
```

### 2.2 输出 Slide Schema

**必须先阅读 [slide-schema.md](references/slide-schema.md)** 了解完整 JSON 格式。

每张幻灯片至少包含：
- `type`：slide 类型（title / content / chart / split / quote）
- `layout`：布局方案
- `design`：配色、背景
- `elements`：所有文字、图表、图标元素

---

## 阶段 3：PptxGenJS 渲染

**必须先阅读 [render-guide.md](references/render-guide.md)**，然后：

1. 安装依赖：`npm install pptxgenjs react react-dom react-icons sharp`
2. 将 Slide Schema 转换为 Node.js 脚本（一个文件）
3. 运行脚本生成 .pptx
4. 将文件复制到 `/mnt/user-data/outputs/`

```bash
node generate.js
cp output.pptx /mnt/user-data/outputs/presentation.pptx
```

---

## 阶段 4：质检与修复

**必须先阅读 [qa-guide.md](references/qa-guide.md)**，依次执行：

1. 内容提取校验
2. 截图视觉检查
3. 发现问题 → 修改脚本 → 重新生成
4. 通过后使用 `present_files` 交付文件

**停止条件**：完成一次修复循环后，除非有明显用户可见的缺陷，否则停止迭代。

---

## 设计原则（每次生成都要遵守）

- **不要使用默认蓝色** — 根据主题选择有个性的配色
- **每张幻灯片必须有视觉元素** — 图标、图表、形状、背景色块
- **不要堆砌文字** — 每页要点不超过 5 条，每条不超过 15 字
- **标题页和结尾页用深色背景**，内容页用浅色（三明治结构）
- **统一视觉语言** — 选定一种装饰元素后贯穿全文

---

## 常见任务快速路径

### 从主题生成（最常见）
→ 跳过文件读取，直接规划大纲，输出 schema，渲染

### 从文档生成
→ 读取文件提取要点，整合进 schema，渲染

### 数据驱动型 PPT
→ 解析 CSV/表格，判断最合适的图表类型，在 schema 中标注数据，渲染时用 `addChart()`

### 批量生成多份
→ 循环调用渲染脚本，每份传入不同的 schema JSON 参数
